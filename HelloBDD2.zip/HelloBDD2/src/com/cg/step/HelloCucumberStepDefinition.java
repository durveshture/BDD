package com.cg.step;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HelloCucumberStepDefinition {

	@Before(order=1)
	public void init() {
		System.out.println("This will execute before every step");
	}
	
	@Before(order=0)
	public void init2(){
		System.out.println("getting started...");
	}
	
	@After(order=1)
	public void destroy(){
		System.out.println("scenario test ends");
	}
	
	@After(order=0)
	public void destroy2(){
		System.out.println("killing process....");
	}

	@Given("^Hello given step$")
	public void helloGivenStep() throws Throwable {
		System.out.println("Saying hello to Given step");
	}

	@When("Hello when step")
	public void helloWhenStep() throws Throwable {
		System.out.println("Saying hello to When step");
	}

	@Then("Hello then step")
	public void helloThenStep() throws Throwable {
		System.out.println("Saying hello to Then step");
	}
	
	@Given("^Bye given step$")
	public void byeGivenStep() throws Throwable {
		System.out.println("Saying bye to given step");
	}

	@When("^Bye when step$")
	public void byeWhenStep() throws Throwable {
		System.out.println("Saying bye to when step");
	}

	@Then("^Bye then step$")
	public void byeThenStep() throws Throwable {
		System.out.println("Saying bye to Then step");
	}
	
	@Given("^Attended training$")
	public void attendedTraining() throws Throwable {
		System.out.println("attended training");
	}

	@When("^Clear L(\\d+)$")
	public void clearL1(int arg1) throws Throwable {
		System.out.println("clear L1");
	}

	@Then("^Become employee$")
	public void becomeEmployee() throws Throwable {
		System.out.println("becomes employee");
	}


}
