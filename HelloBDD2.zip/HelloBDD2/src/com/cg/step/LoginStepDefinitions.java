package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Login;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinitions {
	WebDriver driver;
	WebElement element;
	private Login login;

	@Before
	public void init() {

		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
		Login login = new Login();
	}

	// @visitlogin
	// Scenario: Visit login page
	// Given Chrome is open
	// When URL is specified
	// Then Login page must open
	// @Given("^Chrome is open$")
	// public void chrome_is_open() throws Throwable {
	// // open chrome browser
	//
	// }
	//
	// @When("^URL is specified$")
	// public void url_is_specified() throws Throwable {
	// // open login page in chrome
	//
	// }
	//
	// @Then("^Login page must open$")
	// public void login_page_must_open() throws Throwable {
	// // verify title of the page
	// if (driver.getTitle().equals("Login page")) {
	// System.out.println("title verified");
	// }
	// Thread.sleep(1000);
	// }

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		// Thread.sleep(5000);
		String url = "file:///C:/BDD workspace/HelloBDD2/html/login.html";
		driver.get(url);
		login = new Login();
		PageFactory.initElements(driver, login);
		Thread.sleep(1000);
	}

	@When("^User enters username$")
	public void user_enters_username() throws Throwable {
		// WebElement uname = driver.findElement(By.id("username"));
		// uname.sendKeys("adm");
		login.selectUser(0);
		login.setUsername("adm");
		Thread.sleep(1000);
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		// Thread.sleep(5000);
		// WebElement form = driver.findElement(By.tagName("form"));
		// form.submit();
		login.submitForm();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		// WebElement upass = driver.findElement(By.id("password"));
		// WebElement uname = driver.findElement(By.id("username"));
		// uname.sendKeys("admin");
		// upass.sendKeys("123");
		login.selectUser(0);
		login.setUsername("admin");
		login.setPassword("123");
		Thread.sleep(1000);
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		// element=driver.findElement(By.id("password"));
		// WebElement form = driver.findElement(By.tagName("form"));
		// form.submit();
		login.submitForm();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {

	}

	@Then("^show successfull alert$")
	public void show_successfull_alert() throws Throwable {

		// WebElement upass = driver.findElement(By.id("password"));
		// WebElement uname = driver.findElement(By.id("username"));
		// WebElement form = driver.findElement(By.tagName("form"));
		// uname.sendKeys("admin");
		// upass.sendKeys("12345");
		// form.submit();
		login.setUsername("admin");
		login.setPassword("12345");
		login.setRole(1);
		login.selectUser(0);
		login.submitForm();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@Given("^User is on Login Page$")
	public void user_is_on_Login_Page() throws Throwable {
	}

	@When("^user selects role$")
	public void user_selects_role() throws Throwable {
		login.selectUser(0);
		login.setUsername("admin");
		login.setPassword("12345");
		login.setRole(0);
		Thread.sleep(1000);
	}

	@Then("^validate role$")
	public void validate_role() throws Throwable {
		
		login.submitForm();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user selects usertype$")
	public void user_selects_usertype() throws Throwable {
		login.selectUser(1);
		login.setUsername("admin");
		login.setPassword("12345");
		login.setRole(0);
		Thread.sleep(1000);
	}

	@Then("^validate usertype$")
	public void validate_usertype() throws Throwable {
		login.submitForm();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	
	@When("^user checks rememberme$")
	public void user_checks_rememberme() throws Throwable {
		login.selectUser(0);
		login.setUsername("admin");
		login.setPassword("12345");
		login.setRole(1);
		login.checkRememberMe();
		Thread.sleep(1000);
	}

	@Then("^validate rememberme$")
	public void validate_rememberme() throws Throwable {
		login.submitForm();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@Then("^Validate login page$")
	public void validate_login_page() throws Throwable {
		
	}
	
	@After
	public void destroy() {
		driver.close();
	}

}
