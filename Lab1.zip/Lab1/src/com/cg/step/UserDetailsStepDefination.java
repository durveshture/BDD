package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.CompTrak;
import com.cg.bean.Equipment;
import com.cg.bean.User;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserDetailsStepDefination {

	private WebDriver driver;
	private User user;
	private CompTrak compTrak;
	private Equipment equip;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}
	
	@Given("^User is on Login form$")
	public void user_is_on_Login_form() throws Throwable {
		driver.get("file:///C:/BDD%20workspace/Lab1/html/login.html");
		Thread.sleep(1000);
		user = new User();
		PageFactory.initElements(driver, user);
	}



	@When("^User selects authorization Type$")
	public void user_selects_authorization_Type() throws Throwable {
		user.selectType(2);
	}

	@Then("^Validate authorization Type$")
	public void validate_authorization_Type() throws Throwable {
		user.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters UserId$")
	public void user_enters_UserId() throws Throwable {
		user.selectType(2);
		user.setUserId("123");
	}

	@Then("^Validate UserId$")
	public void validate_UserId() throws Throwable {
		user.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		user.selectType(2);
		user.setUserId("1234");
		user.setUserPass("abc");
	}

	@Then("^Validate Password$")
	public void validate_Password() throws Throwable {
		user.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	@When("^User login form$")
	public void user_login_form() throws Throwable {
		user.selectType(2);
		user.setUserId("1234");
		user.setUserPass("abcd");
	}

	@Then("^show successful login alert$")
	public void show_successful_login_alert() throws Throwable {
		user.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	
	@Given("^User is on Equipment form$")
	public void user_is_on_Equipment_form() throws Throwable {
		driver.get("file:///C:/BDD%20workspace/Lab1/html/equipment.html");
		Thread.sleep(1000);
		equip = new Equipment();
		PageFactory.initElements(driver, equip);
	}

	@When("^user enters invalid purchaseMethod$")
	public void user_enters_invalid_purchaseMethod() throws Throwable {
		equip.setPurchaseMethod("");
	}

	@Then("^display 'Please fill the Purchase Method'$")
	public void display_Please_fill_the_Purchase_Method() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid sequenceNumber$")
	public void user_enters_invalid_sequenceNumber() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("");
	}

	@Then("^display 'Please fill the Sequence Number'$")
	public void display_Please_fill_the_Sequence_Number() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid equipmentCode$")
	public void user_enters_invalid_equipmentCode() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("");
	}

	@Then("^display 'Please fill the Equipment Code'$")
	public void display_Please_fill_the_Equipment_Code() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid deptId$")
	public void user_enters_invalid_deptId() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("");
	}

	@Then("^display 'Please fill the Dept ID'$")
	public void display_Please_fill_the_Dept_ID() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid useStatus$")
	public void user_enters_invalid_useStatus() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(0);
	}

	@Then("^display 'Please fill the Use Status'$")
	public void display_Please_fill_the_Use_Status() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid costCenter$")
	public void user_enters_invalid_costCenter() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("");
	}

	@Then("^display 'Please fill the Cost Center'$")
	public void display_Please_fill_the_Cost_Center() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid installDate$")
	public void user_enters_invalid_installDate() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("");
	}

	@Then("^display 'Please fill the Install Date'$")
	public void display_Please_fill_the_Install_Date() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid auditIndicator$")
	public void user_enters_invalid_auditIndicator() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/4/2019");
		equip.setAuditIndictor("");
	}

	@Then("^display 'Please fill the Audit Indicator'$")
	public void display_Please_fill_the_Audit_Indicator() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid auditDate$")
	public void user_enters_invalid_auditDate() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/4/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("");
	}

	@Then("^display 'Please fill the Audit Date'$")
	public void display_Please_fill_the_Audit_Date() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid stock$")
	public void user_enters_invalid_stock() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("");
	}

	@Then("^display 'Please fill the Stock'$")
	public void display_Please_fill_the_Stock() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	
	@When("^user enters invalid location$")
	public void user_enters_invalid_location() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("2");
		equip.setLocation(0);
	}

	@Then("^display 'Please fill the Location'$")
	public void display_Please_fill_the_Location() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid locationId$")
	public void user_enters_invalid_locationId() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("2");
		equip.setLocation(1);
		equip.setLocationId("");
	}

	@Then("^display 'Please fill the Location ID'$")
	public void display_Please_fill_the_Location_ID() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	
	@When("^User register form$")
	public void user_register_form() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("2");
		equip.setLocation(2);
		equip.setLocationId("123");
	}

	@Then("^show successful register alert$")
	public void show_successful_register_alert() throws Throwable {
		equip.clickRegister();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	
	@Given("^User is on Computer form$")
	public void user_is_on_Computer_form() throws Throwable {
		driver.get("file:///C:/BDD%20workspace/Lab1/html/computer.html");
		Thread.sleep(1000);
		compTrak = new CompTrak();
		PageFactory.initElements(driver, compTrak);
	}

	@When("^user enters url$")
	public void user_enters_url() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid computerName$")
	public void user_enters_invalid_computerName() throws Throwable {
      compTrak.setComputerName("");
	}

	@Then("^display 'Please fill the Computer Name'$")
	public void display_Please_fill_the_Computer_Name() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid diskCapacity$")
	public void user_enters_invalid_diskCapacity() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("");
	}

	@Then("^display 'Please fill the Disk Capacity'$")
	public void display_Please_fill_the_Disk_Capacity() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid totalInstalledMemory$")
	public void user_enters_invalid_totalInstalledMemory() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("");
	}

	@Then("^display 'Please fill the Total Installed Memory'$")
	public void display_Please_fill_the_Total_Installed_Memory()
			throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid networkCardNumber$")
	public void user_enters_invalid_networkCardNumber() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("");
	}

	@Then("^display 'Please fill the Network Card Number'$")
	public void display_Please_fill_the_Network_Card_Number() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid networkCardManufacturer$")
	public void user_enters_invalid_networkCardManufacturer() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("");
	}

	@Then("^display 'Please fill the Network Card Manufacturer'$")
	public void display_Please_fill_the_Network_Card_Manufacturer()
			throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid freeSpace$")
	public void user_enters_invalid_freeSpace() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("CISCO");
		compTrak.setFreeSpace("");
	}

	@Then("^display 'Please fill the Free Space'$")
	public void display_Please_fill_the_Free_Space() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid operatingSystem$")
	public void user_enters_invalid_operatingSystem() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("CISCO");
		compTrak.setFreeSpace("500gb");
		compTrak.setOperatingSystem("");
	}

	@Then("^display 'Please fill the Operating System'$")
	public void display_Please_fill_the_Operating_System() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid osVersion$")
	public void user_enters_invalid_osVersion() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("CISCO");
		compTrak.setFreeSpace("500gb");
		compTrak.setOperatingSystem("windows");
		compTrak.setOsVersion("");
	}

	@Then("^display 'Please fill the OS Version'$")
	public void display_Please_fill_the_OS_Version() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("CISCO");
		compTrak.setFreeSpace("500gb");
		compTrak.setOperatingSystem("windows");
		compTrak.setOsVersion("10");
	}

	@Then("^show successful submit alert$")
	public void show_successful_submit_alert() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
}
