package hotelBooking;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import pageBean.HotelBookingPageFactory;

public class stepDefHotelBooking {
	
	private static WebDriver driver;
	private HotelBookingPageFactory objhbpg;
	String BaseURL,NodeURL;
	
	@Before
	public void beforeLogin()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("^User is on 'hotelBooking' Page$")
	public void user_is_on_hotelBooking_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("driver = "+driver);
		objhbpg = new HotelBookingPageFactory(driver);

		driver.get("d:\\WebDriver\\hotelBooking.html");
	}

	@When("^user enters invalid FirstName$")
	public void user_enters_invalid_FirstName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("");
	    objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the FirstName'$")
	public void display_Please_fill_the_FirstName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(driver.switchTo().alert().getText(),"Please fill the First Name");
	}

	@When("^user enters invalid LastName$")
	public void user_enters_invalid_LastName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("Rima");
		objhbpg.setPflname("");
	    objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the LastName'$")
	public void display_Please_fill_the_LastName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Last Name");
	}

	@When("^user enters invalid Email$")
	public void user_enters_invalid_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("");
	    objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Email");
	}

	@When("^user enters invalid MobileNo$")
	public void user_enters_invalid_MobileNo() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
	    objhbpg.setPfmobile("");
	    objhbpg.setPfbutton();
	    
	}

	@Then("^display 'Please fill the MobileNo'$")
	public void display_Please_fill_the_MobileNo() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Mobile No.");
	}

	@When("^user enters invalid ContactNo$")
	public void user_enters_invalid_ContactNo() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
		objhbpg.setPfmobile("98989");
		objhbpg.setPfbutton();
	    
	}

	@Then("^display 'Please Enter Valid Contact No'$")
	public void display_Please_Enter_Valid_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter valid Contact no.");
	    
	}

	@When("^user enters invalid NumberOfPeopleAttending$")
	public void user_enters_invalid_NumberOfPeopleAttending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
		objhbpg.setPfmobile("9898998989");
		objhbpg.setPfpersons(0);
	    
	}

	@Then("^display 'Please select the number of People attending'$")
	public void display_Please_select_the_number_of_People_attending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(driver.switchTo().alert().getText(),"Please select the number of people attending");
	}

	
	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
		objhbpg.setPfmobile("9898998989");
		objhbpg.setPfpersons(2);
		objhbpg.setPfcity("");
		objhbpg.setPfbutton();

	}

	@Then("^display 'Please fill the City'$")
	public void display_Please_fill_the_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(driver.switchTo().alert().getText(), "Please select city");
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
		objhbpg.setPfmobile("9898998989");
		objhbpg.setPfpersons(2);
		objhbpg.setPfcity("Pune");
		objhbpg.setPfstate("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(driver.switchTo().alert().getText(), "Please select state");
	}

	@When("^user enters invalid CardHolderName$")
	public void user_enters_invalid_CardHolderName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
		objhbpg.setPfmobile("9898998989");
		objhbpg.setPfpersons(2);
		objhbpg.setPfcity("Pune");
		objhbpg.setPfstate("Maharashtra");
		objhbpg.setPfcardholder("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the CardHolderName'$")
	public void display_Please_fill_the_CardHolderName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Card holder name");
	}

	@When("^user enters invalid DebitCardNumber$")
	public void user_enters_invalid_DebitCardNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
		objhbpg.setPfmobile("9898998989");
		objhbpg.setPfpersons(2);
		objhbpg.setPfcity("Pune");
		objhbpg.setPfstate("Maharashtra");
		objhbpg.setPfcardholder("Ram");
		objhbpg.setPfdebit("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the DebitCardNumber'$")
	public void display_Please_fill_the_DebitCardNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit card Number");
	    
	}

	@When("^user enters invalid CardExpirationMonth$")
	public void user_enters_invalid_CardExpirationMonth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
		objhbpg.setPfmobile("9898998989");
		objhbpg.setPfpersons(2);
		objhbpg.setPfcity("Pune");
		objhbpg.setPfstate("Maharashtra");
		objhbpg.setPfcardholder("Ram");
		objhbpg.setPfdebit("5656767676767");
		objhbpg.setPfmonth("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the CardExpirationMonth'$")
	public void display_Please_fill_the_CardExpirationMonth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill expiration month");
		
	}

	@When("^user enters invalid CardExpirationYear$")
	public void user_enters_invalid_CardExpirationYear() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
		objhbpg.setPfmobile("9898989898");
		objhbpg.setPfpersons(2);
		objhbpg.setPfcity("Pune");
		objhbpg.setPfstate("Maharashtra");
		objhbpg.setPfcardholder("Ram");
		objhbpg.setPfdebit("5656767676767");
		objhbpg.setPfmonth("January");
		objhbpg.setPfyear("");
		objhbpg.setPfbutton();
	    
	}

	@Then("^display 'Please fill the CardExpirationYear'$")
	public void display_Please_fill_the_CardExpirationYear() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the expiration year");
	    
	}
	
	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		objhbpg.setPffname("Rima");
	    objhbpg.setPflname("Rai");
	    objhbpg.setPfemail("rima@gmail.com");
		objhbpg.setPfmobile("98989");
		objhbpg.setPfpersons(2);
		objhbpg.setPfcity("Pune");
		objhbpg.setPfstate("Maharashtra");
		objhbpg.setPfcardholder("Ram");
		objhbpg.setPfdebit("5656767676767");
		objhbpg.setPfmonth("January");
		objhbpg.setPfyear("2021");
		objhbpg.setPfbutton();
	}

	@Then("^display 'success' Page AND display 'Booking Completed!'$")
	public void display_success_Page_AND_display_Booking_Completed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	   driver.get("D:\\WebDriver\\success.html");
	  
	}



}
